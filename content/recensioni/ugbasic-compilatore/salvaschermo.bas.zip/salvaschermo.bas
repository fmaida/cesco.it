﻿init:
	RANDOMIZE 
	tt = "MSX Rocks"
	x = 1
	y = RND(23)+ 1
	x1 = 0
	y1 = 0
	color = RND(13) + 2
	dz = 1
	s = ""
	
mainloop:
	DO
		REM PEN color
		REM LOCATE x1, y1
		REM PEN 15
		REM PRINT CHR(254)
		REM y1 = y1 + 1
		REM IF y1 > 22 THEN
		REM 	y1 = 0
		REM 	x1 = x1 + 1
		REM		IF x1 > 30 THEN
		REM			x1 = 0
		REM			y1 = 0
		REM		ENDIF
		REM ENDIF
		LOCATE x, y	
		IF dz == 1 THEN
			PRINT SPACE(1);
		ENDIF
		REM IF s <> tt THEN
		s = tt
		REM ENDIF
		FOR i = 1 TO LEN(tt)
			color = color + 1
			IF color > 13 THEN
				color = 0
			ENDIF
			PEN color + 2
			PRINT MID(tt, i, 1);
		NEXT
		IF dz == -1 THEN
			PRINT SPACE(1);
		ENDIF
		WAIT 150 MILLISECOND
		x = x + dz
		IF dz == 1 THEN
			IF x > 20 THEN
				x = 20
				dz = -dz
			ENDIF
		ENDIF
		IF dz == -1 THEN
			IF x < 1 THEN
				x = 1
				LOCATE x, y
				PRINT SPACE(LEN(tt));
				y = RND(23) + 1
				dz = -dz
			ENDIF
		ENDIF
		REM color = RND(13) + 2
	LOOP


